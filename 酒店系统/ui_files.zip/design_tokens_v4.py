# design_tokens_v4.py
"""[v4 实现层] 本文件是 v4 设计系统的实际实现（非 re-export 垫片）。

企业级设计系统 v4.0 - 完全替代 design_tokens.py
包含：颜色、间距、排版、阴影、动画。

保留目的：
- 提供完整设计系统 Enum/工具/`_p()` token 解析入口。
- 由 design_tokens.py（兼容入口）re-export 本模块的 Enum/工具供旧代码使用。
- 由 brand_config_v4.py / frontdesk_ui_v4.py 直接 import 本模块常量。

注意：本文件不是 re-export 垫片，是 v4 实现本体。删了它 design_tokens.py /
brand_config_v4.py / frontdesk_ui_v4.py 全部 import 崩溃。v4 命名表明它是 v3
重构后的新版本，并非死代码。

当前引用方（rg 查）：
- design_tokens.py:9 `from design_tokens_v4 import (Animation, BorderRadius, ...)`
- brand_config_v4.py:15 `from design_tokens_v4 import ColorPrimary`
- frontdesk_ui_v4.py:5 `from design_tokens_v4 import SpacingDesktop, Shadow, _p`
- tabs/hotel_overview_tab_v4.py:25 `from design_tokens_v4 import ColorRoomStatus`
- tests/ui_ux_tests.py:11 `from design_tokens_v4 import validate_contrast_ratio, ...`
"""

from enum import Enum
from typing import Dict, Tuple, Optional

# ════════════════════════════════════════════════
# 第一层：颜色系统
# ════════════════════════════════════════════════

class ColorPrimary(Enum):
    """原始品牌色 - 每色3梯度"""
    GOLD_LIGHT = "#D4B896"      # 亮
    GOLD_STANDARD = "#C4A86A"   # 标准（品牌线）
    GOLD_DARK = "#8B7D3F"       # 暗
    
    GREEN_LIGHT = "#D4E8D4"
    GREEN_STANDARD = "#2C3E36"  # old_money深绿
    GREEN_DARK = "#1A2620"
    
    RED_LIGHT = "#FFE8E8"
    RED_STANDARD = "#E74C3C"    # 危险
    RED_DARK = "#C0392B"
    
    BLUE_LIGHT = "#E8F4FF"
    BLUE_STANDARD = "#3498DB"
    BLUE_DARK = "#2980B9"


class ColorSemantic(Enum):
    """语义色 - 按用途命名，而非颜色本身

    ⚠️ 设计参考值：本 Enum 的色值是 v4 设计规范的参考色，**与运行时四主题色不对应**。
    运行时取色请统一用 `from design_tokens import _p; _p("primary")`，
    它会根据当前主题（晨雾/午荫/暮霞/夜墨）返回实际色值。
    本 Enum 仅用于：设计文档对照、brand_config_v4 品牌色派生、UI 测试断言。
    """
    PRIMARY = "#2C3E36"         # 主操作（设计参考，运行时用 _p("primary")）
    SECONDARY = "#C4A86A"       # 品牌强调（金线）
    SUCCESS = "#4CAF50"         # 成功
    WARNING = "#FF9800"         # 警告
    DANGER = "#E74C3C"          # 危险/错误
    INFO = "#3498DB"            # 信息


class ColorNeutral(Enum):
    """中性色 - 严格按WCAG AA达成对比度"""
    TEXT_PRIMARY = "#1A1A1A"    # 对比度 20:1 ✓ AAA
    TEXT_SECONDARY = "#404040"  # 对比度 10:1 ✓ AA
    TEXT_TERTIARY = "#686868"   # 对比度 6:1 ✓ AA
    TEXT_DISABLED = "#AAAAAA"   # 对比度 4.5:1 ✓ AA
    TEXT_MUTED = "#999999"      # 低优先级文字
    
    BORDER_STRONG = "#D0D0D0"   # 强边框
    BORDER_MEDIUM = "#E0E0E0"   # 中等边框
    BORDER_LIGHT = "#F0F0F0"    # 浅边框
    
    BG_PRIMARY = "#FFFFFF"      # 白色背景
    BG_SECONDARY = "#F8F8F8"    # 浅灰背景
    BG_TERTIARY = "#F0F0F0"     # 更浅灰


class ColorState(Enum):
    """状态色 - 带透明度的变体"""
    SUCCESS_SOFT = "rgba(76, 175, 80, 0.1)"
    WARNING_SOFT = "rgba(255, 152, 0, 0.1)"
    DANGER_SOFT = "rgba(231, 76, 60, 0.08)"
    INFO_SOFT = "rgba(52, 152, 219, 0.1)"


class ColorRoomStatus(Enum):
    """房态色彩编码 - 国际通用标准"""
    VACANT = "#4CAF50"          # 绿 - 可入住
    OCCUPIED = "#2196F3"        # 蓝 - 已入住
    DIRTY = "#FF9800"           # 橙 - 脏房
    MAINTENANCE = "#9C27B0"     # 紫 - 维修
    OVERTIME = "#F44336"        # 红 - 超时


# ════════════════════════════════════════════════
# 第二层：间距系统（8级递进）
# ════════════════════════════════════════════════

class SpacingDesktop:
    """PC端间距(>=1080px) - 充分宽松"""
    XS = 4       # icon + text 之间
    SM = 8       # 同行多个元素
    MD = 12      # 表单行与行之间
    LG = 16      # 卡片内部分组
    XL = 20      # 侧栏内分组
    XXL = 24     # 顶部导航下方
    XXXL = 32    # 页面主区域之间
    XXXXL = 40   # 页面分屏之间


class SpacingTablet:
    """Tablet端间距(768-1079px) - 中等间距"""
    XS = 3
    SM = 6
    MD = 10
    LG = 14
    XL = 18
    XXL = 20
    XXXL = 28
    XXXXL = 36


class SpacingMobile:
    """Mobile端间距(<768px) - 紧凑但舒适"""
    XS = 2
    SM = 4
    MD = 8
    LG = 12
    XL = 16
    XXL = 20
    XXXL = 24
    XXXXL = 32


def get_spacing(level: str, screen_width: int) -> int:
    """根据屏幕宽度返回对应的间距"""
    if screen_width >= 1080:
        return getattr(SpacingDesktop, level.upper(), 0)
    elif screen_width >= 768:
        return getattr(SpacingTablet, level.upper(), 0)
    else:
        return getattr(SpacingMobile, level.upper(), 0)


# ════════════════════════════════════════════════
# 第三层：排版系统（6层等级）
# ════════════════════════════════════════════════

class Typography:
    """排版系统 - 每层有明确用途"""
    
    class H1:
        SIZE = 28
        WEIGHT = 700  # bold
        LINE_HEIGHT = 1.2
        LETTER_SPACING = -0.5
        MARGIN_BOTTOM = SpacingDesktop.XXL
    
    class H2:
        SIZE = 24
        WEIGHT = 700
        LINE_HEIGHT = 1.25
        LETTER_SPACING = -0.3
        MARGIN_BOTTOM = SpacingDesktop.LG
    
    class H3:
        SIZE = 18
        WEIGHT = 600  # semibold
        LINE_HEIGHT = 1.3
        LETTER_SPACING = 0
        MARGIN_BOTTOM = SpacingDesktop.SM
    
    class Body:
        SIZE = 13          # PC最优阅读大小
        WEIGHT = 400
        LINE_HEIGHT = 1.5  # 19.5px - 舒适
        LETTER_SPACING = 0
    
    class Caption:
        SIZE = 11
        WEIGHT = 400
        LINE_HEIGHT = 1.4
        LETTER_SPACING = 0.3
    
    class Label:
        SIZE = 12
        WEIGHT = 500  # medium
        LINE_HEIGHT = 1.4
        LETTER_SPACING = 0


class Fonts:
    """字体栈 - 优化中英混合"""
    DEFAULT = [
        "Segoe UI",          # Windows优先
        "Roboto",            # Android
        "-apple-system",     # iOS/Mac
        "Microsoft YaHei",   # 中文 Windows
        "PingFang SC",       # 中文 Mac
        "Noto Sans CJK SC",  # 中文 Linux
    ]
    
    MONOSPACE = [
        "JetBrains Mono",
        "Fira Code",
        "Courier New",
    ]


# ════════════════════════════════════════════════
# 第四层：圆角系统（4层等级）
# ════════════════════════════════════════════════

class BorderRadius:
    """圆角 - 保持品牌一致性"""
    NONE = 0
    SM = 4      # 输入框、小组件
    MD = 6      # 按钮、卡片
    LG = 8      # 模态框、大卡片
    XL = 12     # 特殊容器


# ════════════════════════════════════════════════
# 第五层：阴影系统
# ════════════════════════════════════════════════

class Shadow:
    """阴影 - 创建视觉层级"""
    NONE = "none"
    SM = "0 1px 3px rgba(0, 0, 0, 0.08)"
    MD = "0 2px 8px rgba(0, 0, 0, 0.1)"
    LG = "0 4px 12px rgba(0, 0, 0, 0.12)"
    XL = "0 8px 24px rgba(0, 0, 0, 0.15)"
    
    # 特殊阴影
    BUTTON = "0 2px 8px rgba(0, 0, 0, 0.15)"
    CARD = "0 2px 8px rgba(0, 0, 0, 0.08)"
    MODAL = "0 8px 24px rgba(0, 0, 0, 0.2)"


# ════════════════════════════════════════════════
# 第六层：动画系统
# ════════════════════════════════════════════════

class Animation:
    """动画 - 流畅的用户体验"""
    TIMING = {
        "fast": "0.1s",       # 快速反馈（100ms）
        "normal": "0.2s",     # 标准转换（200ms）
        "slow": "0.3s",       # 缓慢进入（300ms）
        "slower": "0.5s",     # 较慢进入（500ms）
    }
    
    EASING = {
        "ease_in_out": "cubic-bezier(0.4, 0, 0.2, 1)",
        "ease_out": "cubic-bezier(0.0, 0, 0.2, 1)",
        "ease_in": "cubic-bezier(0.4, 0, 1, 1)",
        "ease_linear": "linear",
    }
    
    @staticmethod
    def transition(properties: list, timing: str = "normal", easing: str = "ease_in_out") -> str:
        """生成过渡CSS"""
        prop_str = ", ".join(properties)
        return f"{prop_str} {Animation.TIMING[timing]} {Animation.EASING[easing]}"


# ════════════════════════════════════════════════
# 工具函数
# ════════════════════════════════════════════════

def get_color_value(color: Enum) -> str:
    """从Enum获取颜色值"""
    return color.value if hasattr(color, 'value') else str(color)


def get_hex_from_rgb(r: int, g: int, b: int, alpha: float = 1.0) -> str:
    """从RGB转换为HEX"""
    if alpha < 1.0:
        return f"rgba({r}, {g}, {b}, {alpha})"
    return f"#{r:02x}{g:02x}{b:02x}"


# ════════════════════════════════════════════════
# 验证函数 - 质量保证
# ════════════════════════════════════════════════

def validate_contrast_ratio(fg_hex: str, bg_hex: str) -> float:
    """计算WCAG对比度比例（简化版）"""
    def hex_to_rgb(hex_color):
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def relative_luminance(rgb):
        r, g, b = [x/255.0 for x in rgb]
        r = r/12.92 if r <= 0.03928 else ((r+0.055)/1.055)**2.4
        g = g/12.92 if g <= 0.03928 else ((g+0.055)/1.055)**2.4
        b = b/12.92 if b <= 0.03928 else ((b+0.055)/1.055)**2.4
        return 0.2126*r + 0.7152*g + 0.0722*b
    
    fg_rgb = hex_to_rgb(fg_hex)
    bg_rgb = hex_to_rgb(bg_hex)
    
    l1 = relative_luminance(fg_rgb)
    l2 = relative_luminance(bg_rgb)
    
    lighter = max(l1, l2)
    darker = min(l1, l2)
    
    return (lighter + 0.05) / (darker + 0.05)


# 对比度检查
COLOR_CONTRAST_VALIDATION = [
    (ColorNeutral.TEXT_PRIMARY.value, ColorNeutral.BG_PRIMARY.value, 20),  # AAA
    (ColorNeutral.TEXT_SECONDARY.value, ColorNeutral.BG_PRIMARY.value, 10),  # AA
    (ColorSemantic.PRIMARY.value, "#FFFFFF", 7),  # 按钮文字
]


# ════════════════════════════════════════════════
# 对外导出 - 简化使用
# ════════════════════════════════════════════════

def _p(key: str) -> str:
    """v8 四时之色：从 theme_palette 动态获取 token，不再硬编码。"""
    try:
        from theme_palette import theme_tokens, resolve_theme_name
        import database as _db
        theme_name = None
        try:
            theme_name = _db.db.get_config("theme") or None
        except Exception:
            pass
        resolved = resolve_theme_name(theme_name)
        tokens = theme_tokens(resolved)
        return tokens.get(key, "")
    except Exception:
        from design_tokens import _NEUTRAL_FALLBACK
        return _NEUTRAL_FALLBACK.get(key, "#2A2A2E")


# ════════════════════════════════════════════════
# 测试/验证代码
# ════════════════════════════════════════════════

if __name__ == "__main__":
    # 验证所有对比度
    print("颜色对比度验证：")
    for fg, bg, expected in COLOR_CONTRAST_VALIDATION:
        ratio = validate_contrast_ratio(fg, bg)
        status = "OK" if ratio >= expected else "FAIL"
        print(f"{status} {fg} vs {bg}: {ratio:.1f}:1 (需要 >= {expected}:1)")
    
    # 打印设计系统信息
    print("\n设计系统已加载:")
    print(f"- 颜色系统: 原始色(12) + 语义色(6) + 中性色(9) + 状态色(4)")
    print(f"- 间距系统: 8级递进 × 3种屏幕(PC/Tablet/Mobile)")
    print(f"- 排版系统: 6层等级")
    print(f"- 圆角系统: 4层等级")
    print(f"- 阴影系统: 5层等级")
    print(f"- 动画系统: 4种速度 × 4种缓动")
