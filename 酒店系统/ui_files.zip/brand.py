"""ui/branding/brand.py — 品牌配置"""

from __future__ import annotations

from ui.tokens import ColorPrimary

# ── 品牌名称 ──
APP_NAME = "Solid"
APP_NAME_FULL = "Solid PMS"
BRAND_COLOR = ColorPrimary.GOLD_STANDARD.value


def effective_brand(db=None) -> dict:
    """返回当前生效的品牌配置。"""
    try:
        if db is None:
            from database import db as _db
            db = _db
        custom_title = db.get_config("brand_title") or ""
        custom_short = db.get_config("brand_short") or ""
        return {
            "title": custom_title or APP_NAME_FULL,
            "short": custom_short or APP_NAME,
            "color": BRAND_COLOR,
        }
    except Exception:
        return {"title": APP_NAME_FULL, "short": APP_NAME, "color": BRAND_COLOR}
