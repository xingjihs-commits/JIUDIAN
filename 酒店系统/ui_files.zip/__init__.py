"""ui/ — Solid PMS UI 层

分层:
  ui/tokens/      设计令牌（颜色/间距/排版）
  ui/theme/       主题系统（色板/动画）
  ui/components/  原子组件（按钮/输入框/卡片/弹窗）
  ui/surfaces/    表面工厂（表格/滚动区/分隔线）
  ui/layout/      布局常量（前台度量 FD_*）
  ui/branding/    品牌配置
"""

from ui.tokens import (
    ColorPrimary, ColorSemantic, ColorNeutral, ColorState, ColorRoomStatus,
    SpacingDesktop, SpacingTablet, SpacingMobile, get_spacing,
    Typography, Fonts, BorderRadius, Shadow, Animation,
)
from ui.layout import (
    FD_BTN_H, FD_BTN_H_CRITICAL, FD_BTN_H_PRIMARY, FD_BTN_H_LOW, FD_BTN_MIN_W,
    FD_INPUT_H_SM, FD_INPUT_H, FD_INPUT_H_LG,
    FD_SPACE_XS, FD_SPACE_SM, FD_SPACE_MD, FD_SPACE_LG, FD_SPACE_XL,
    FD_CARD_PADDING, FD_CARD_RADIUS, FD_CARD_SHADOW,
    FD_GOLD_THREAD_WIDTH, FD_SECTION_BAR_H,
    BTN_COLORS, INPUT_COLORS, ROOM_STATUS_COLORS, FD_GOLD_THREAD_COLOR,
)
from ui.branding.brand import APP_NAME, APP_NAME_FULL, effective_brand
from ui.components import ToastManager, ToastType, toast

__all__ = [
    "ColorPrimary", "ColorSemantic", "ColorNeutral", "ColorState", "ColorRoomStatus",
    "SpacingDesktop", "SpacingMobile", "get_spacing",
    "Typography", "Fonts", "BorderRadius", "Shadow", "Animation",
    "FD_BTN_H", "FD_BTN_H_CRITICAL", "FD_BTN_H_PRIMARY", "FD_BTN_MIN_W",
    "FD_INPUT_H", "FD_INPUT_H_LG",
    "FD_SPACE_XS", "FD_SPACE_SM", "FD_SPACE_MD", "FD_SPACE_LG",
    "FD_CARD_PADDING", "FD_CARD_RADIUS", "FD_CARD_SHADOW",
    "FD_GOLD_THREAD_WIDTH", "FD_SECTION_BAR_H",
    "BTN_COLORS", "INPUT_COLORS", "ROOM_STATUS_COLORS", "FD_GOLD_THREAD_COLOR",
    "APP_NAME", "APP_NAME_FULL", "effective_brand",
    "ToastManager", "ToastType", "toast",
]
